# Starter Code for Comp3414 RSA 2018s2
## Installation
Clone this into the catkin workspace src folder (by default this is ~/catkin_ws/src)
```bash
cd ~/catkin_ws/src
git clone -b 18s2 --single-branch git@robolab.cse.unsw.edu.au:addo/comp3431-rsa.git
```

## Changes in 18s2
* Remove crosbot dependencies
* Remove rviz control panel
* Remove control receive node (You are welcome to try get these working again)
