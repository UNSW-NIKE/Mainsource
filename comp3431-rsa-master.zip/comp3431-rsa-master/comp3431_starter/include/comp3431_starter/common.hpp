/*
 * common.hpp
 *
 *  Created on: 05/07/2016
 *      Author: rescue
 */

#ifndef COMP3431_STARTER_COMMON_HPP_
#define COMP3431_STARTER_COMMON_HPP_

#define TURTLEBOT_CONTROL_NAMESPACE             "turtlebot"

#endif /* COMP3431_STARTER_COMMON_HPP_ */
