# -*- coding: utf-8 -*-
import cv2
import numpy as np
 
def extract_white(pic):
    ''''method1：使用inRange方法，拼接mask0,mask1'''
    #img2 = np.fromfile(pic, dtype=np.uint8)
    img = pic.copy()
    img_hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
    rows, cols, channels = img.shape

    # 区间1
    lower_red = np.array([0, 0, 160])
    upper_red = np.array([180, 30, 255])
    mask = cv2.inRange(img_hsv,lower_red,upper_red)
    # cv2.imshow('mask',mask)
    # 保存图片
    #cv2.imencode('.png', mask )[1].tofile(pic)
    kernel = np.ones((3,3),np.uint8)
    opening = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel)
    # inverse = np.ones(closing.shape,dtype='uint8')*255
    # inverse -= closing
    return closing

def extract_left_lane(pic):
    height,width=pic.shape
    leftLane = np.zeros(pic.shape,dtype='uint8')
    leftLane[height//2:,:width//2] = 1
    leftLane *= pic
    _,contours,_ = cv2.findContours(leftLane,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    boundingBoxes = [(cv2.boundingRect(cnt),cnt)for cnt in contours]
    boundingBoxes = sorted(boundingBoxes,key=lambda x:x[0][1]+x[0][3],reverse=True)
    leftLane = np.ones(pic.shape,dtype='uint8')*255
    cv2.drawContours(leftLane,[boundingBoxes[0][1]],-1,(0,0,0),-1)
    return leftLane

for i in range(1,10):
    pic=cv2.imread(str(i)+'.jpg')
    cv2.imshow('pic1',pic)
    pic = extract_white(pic)
    cv2.imshow('pic2',pic)
    leftLane = extract_left_lane(pic)
    cv2.imshow('leftLane',leftLane)
    cv2.waitKey()
    cv2.destroyAllWindows()